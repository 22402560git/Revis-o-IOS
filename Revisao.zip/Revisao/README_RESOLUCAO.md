# Resolução dos exercícios — Revisao (SwiftUI)

As soluções dos exercícios dos capítulos 5, 6, 7, 8 e da revisão geral estão em:

`Revisao/Exercicios/AllExerciseSolutions.swift`

O arquivo reúne as telas, modelos e ViewModels pedidos nos enunciados. Os arquivos `.md` originais de cada capítulo foram mantidos para consulta. Os exemplos didáticos originais das pastas `Cap5`, `Cap6`, `Cap7` e `Cap8` também foram preservados.

## Como abrir

1. Extraia o ZIP.
2. Abra `Revisao.xcodeproj` no Xcode em um Mac.
3. Selecione um simulador iPhone ou um dispositivo conectado.
4. Execute o projeto pelo botão **Run**.
5. Na tela **Exemplos**, abra os exercícios nas seções “Prova — Capítulo 5”, “Prova — Capítulo 6”, “Prova — Capítulo 7”, “Prova — Capítulo 8” e “Revisão — listas, ViewModel e telas”.

O projeto utiliza SwiftUI e os recursos de navegação e formulários disponíveis no SDK indicado pelas configurações do projeto original. A compilação e execução final precisam ser verificadas no Xcode, pois este ambiente não possui o SDK iOS.

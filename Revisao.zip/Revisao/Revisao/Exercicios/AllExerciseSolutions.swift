import SwiftUI

// MARK: - CAPÍTULO 5: ESTADO E CONTROLES

final class FocoViewModel: ObservableObject {
    @Published var materia = ""
    @Published var minutosAlvo = 25
    @Published var nivelFoco = 0.5
    @Published var somLigado = false
    @Published var dataProva = Date()
    var formularioValido: Bool { !materia.trimmingCharacters(in: .whitespaces).isEmpty && nivelFoco > 0 }
    func reiniciar() { materia = ""; minutosAlvo = 25; nivelFoco = 0.5; somLigado = false; dataProva = Date() }
    var estaNoInicio: Bool { materia.isEmpty && minutosAlvo == 25 && nivelFoco == 0.5 && !somLigado }
}

struct FocoView: View {
    @StateObject private var foco = FocoViewModel()
    @State private var mostrarAjustes = false
    @State private var mostrarAlerta = false
    var body: some View {
        VStack(spacing: 22) {
            Image(systemName: "brain.head.profile").font(.system(size: 52)).foregroundStyle(.indigo)
            Text(foco.materia.isEmpty ? "Sem matéria" : foco.materia).font(.title.bold())
            Text("\(foco.minutosAlvo) minutos de estudo").font(.title3)
            PainelFocoView(foco: foco)
            HStack {
                Button("Reiniciar", systemImage: "arrow.counterclockwise") { foco.reiniciar() }.disabled(foco.estaNoInicio)
                Button("Ajustes", systemImage: "slider.horizontal.3") { mostrarAjustes = true }
            }.buttonStyle(.borderedProminent)
        }.padding().navigationTitle("Foco")
        .sheet(isPresented: $mostrarAjustes) { AjustesFocoView(foco: foco, mostrarAlerta: $mostrarAlerta) }
        .alert("Pronto", isPresented: $mostrarAlerta) { Button("OK", role: .cancel) {} } message: { Text("Sessão de \(foco.materia) pronta: \(foco.minutosAlvo) min.") }
    }
}
struct PainelFocoView: View {
    @ObservedObject var foco: FocoViewModel
    var body: some View {
        VStack {
            Slider(value: $foco.nivelFoco, in: 0...1)
                .disabled(foco.materia.trimmingCharacters(in: .whitespaces).isEmpty)
            Text("Nível de foco: \(Int(foco.nivelFoco * 100))%")
        }
    }
}
struct AjustesFocoView: View {
    @ObservedObject var foco: FocoViewModel
    @Binding var mostrarAlerta: Bool
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                TextField("Matéria", text: $foco.materia).textInputAutocapitalization(.words)
                Stepper("Minutos: \(foco.minutosAlvo)", value: $foco.minutosAlvo, in: 5...60)
                Toggle("Som ao terminar", isOn: $foco.somLigado)
                DatePicker("Prova", selection: $foco.dataProva, displayedComponents: .date)
                Button("Salvar") { mostrarAlerta = true; dismiss() }.disabled(!foco.formularioValido)
            }.navigationTitle("Ajustes")
        }
    }
}

struct MixerCorView: View {
    @State private var vermelho = 0.2
    @State private var verde = 0.45
    @State private var azul = 0.85
    @State private var travado = false
    var body: some View {
        VStack(spacing: 24) {
            RoundedRectangle(cornerRadius: 22).fill(Color(red: vermelho, green: verde, blue: azul)).frame(height: 180)
            ControleCorView(vermelho: $vermelho, verde: $verde, azul: $azul, travado: travado)
            Toggle("Travar sliders", isOn: $travado)
            Button("Zerar", systemImage: "arrow.counterclockwise") { vermelho = 0; verde = 0; azul = 0 }.disabled(travado).buttonStyle(.borderedProminent)
        }.padding().navigationTitle("Mixer")
    }
}
struct ControleCorView: View {
    @Binding var vermelho: Double
    @Binding var verde: Double
    @Binding var azul: Double
    let travado: Bool
    var body: some View {
        VStack {
            Group { Text("Vermelho: \(vermelho, specifier: "%.2f")"); Slider(value: $vermelho, in: 0...1).disabled(travado) }
            Group { Text("Verde: \(verde, specifier: "%.2f")"); Slider(value: $verde, in: 0...1).disabled(travado) }
            Group { Text("Azul: \(azul, specifier: "%.2f")"); Slider(value: $azul, in: 0...1).disabled(travado) }
        }
    }
}
struct ReservaSalaView: View {
    @State private var nome = ""
    @State private var sala = "Laboratório"
    @State private var data = Date()
    @State private var pessoas = 10
    @State private var projetor = false
    @State private var mostrarAlerta = false
    var body: some View {
        Form {
            Section("Quem reserva") {
                TextField("Nome", text: $nome).textInputAutocapitalization(.words)
                Picker("Sala", selection: $sala) { Text("Laboratório").tag("Laboratório"); Text("Biblioteca").tag("Biblioteca"); Text("Auditório").tag("Auditório") }
            }
            Section("Quando") {
                DatePicker("Data", selection: $data, displayedComponents: .date)
                Stepper("Pessoas: \(pessoas)", value: $pessoas, in: 1...40)
                Toggle("Projetor", isOn: $projetor)
            }
            Button("Reservar") { mostrarAlerta = true }.disabled(nome.trimmingCharacters(in: .whitespaces).isEmpty)
        }.navigationTitle("Reserva")
        .alert("Reserva feita", isPresented: $mostrarAlerta) { Button("OK", role: .cancel) {} } message: { Text("\(sala) reservada para \(nome), \(pessoas) pessoas. Projetor: \(projetor ? "sim" : "não").") }
    }
}

// MARK: - CAPÍTULO 6: EVENTOS E GESTOS
struct SeloView: View {
    @State private var cor = Color.blue
    @State private var escala: CGFloat = 1
    var body: some View {
        RoundedRectangle(cornerRadius: 18).fill(cor).frame(width: 120, height: 120).scaleEffect(escala)
            .onTapGesture { withAnimation { cor = Color(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1)) } }
            .onLongPressGesture { withAnimation { escala = escala == 1 ? 1.3 : 1 } }
    }
}
struct FigurinhaView: View {
    @State private var posicao = CGSize.zero
    @State private var escala: CGFloat = 1
    @State private var angulo = Angle.zero
    @State private var escalaBase: CGFloat = 1
    var body: some View {
        Circle().fill(.orange.gradient).frame(width: 100, height: 100).overlay { Image(systemName: "star.fill").font(.largeTitle).foregroundStyle(.white) }
            .scaleEffect(escala).rotationEffect(angulo).offset(posicao)
            .gesture(DragGesture().onChanged { posicao = $0.translation }.onEnded { _ in withAnimation { posicao = .zero } })
            .simultaneousGesture(MagnificationGesture().onChanged { escala = min(max(escalaBase * $0, 0.5), 2.5) }.onEnded { _ in escalaBase = escala })
            .simultaneousGesture(RotationGesture().onChanged { angulo = $0 })
    }
}
struct CartazView: View {
    @State private var nome = ""
    @State private var recado = ""
    @State private var mensagemNome = ""
    @State private var mensagemRecado = ""
    @State private var publicado = false
    @State private var publicacoes = 0
    @State private var fechamentos = 0
    private var nomeValido: Bool { let partes = nome.trimmingCharacters(in: .whitespaces).split(whereSeparator: \.isWhitespace); return partes.count >= 2 && !nome.contains(where: { $0.isNumber }) }
    private var recadoValido: Bool { (5...80).contains(recado.trimmingCharacters(in: .whitespaces).count) }
    private func borda(_ texto: String, valido: Bool) -> Color { texto.isEmpty ? .gray : (valido ? .green : .red) }
    var body: some View {
        VStack(spacing: 16) {
            HStack { Text("Publicações: \(publicacoes)"); Spacer(); Text("Fechamentos: \(fechamentos)") }.font(.caption)
            if publicado {
                VStack(spacing: 18) { FigurinhaView(); Text(nome).font(.title.bold()); Text(recado).multilineTextAlignment(.center); Button("Fechar") { publicado = false }.buttonStyle(.borderedProminent) }
                    .frame(maxWidth: .infinity).padding().background(.thinMaterial, in: RoundedRectangle(cornerRadius: 20))
                    .onAppear { publicacoes += 1 }.onDisappear { fechamentos += 1 }
            } else {
                SeloView()
                TextField("Seu nome", text: $nome).textFieldStyle(.roundedBorder).overlay(RoundedRectangle(cornerRadius: 8).stroke(borda(nome, valido: nomeValido), lineWidth: 2))
                    .onChange(of: nome) { _, novo in mensagemNome = novo.isEmpty ? "" : (nomeValido ? "Nome válido." : "Use nome e sobrenome, sem números.") }
                TextField("Recado", text: $recado, axis: .vertical).textFieldStyle(.roundedBorder).overlay(RoundedRectangle(cornerRadius: 8).stroke(borda(recado, valido: recadoValido), lineWidth: 2))
                    .onChange(of: recado) { _, novo in let n = novo.trimmingCharacters(in: .whitespaces).count; mensagemRecado = novo.isEmpty ? "" : (n < 5 ? "Recado curto demais." : (n > 80 ? "Recado longo demais." : "Recado válido.")) }
                Text(!nomeValido && !mensagemNome.isEmpty ? mensagemNome : (!recadoValido && !mensagemRecado.isEmpty ? mensagemRecado : (nomeValido && recadoValido ? "Pronto para publicar." : ""))).font(.caption)
                Button("Publicar") { publicado = true }.buttonStyle(.borderedProminent).disabled(!nomeValido || !recadoValido)
            }
        }.padding().navigationTitle("Cartaz")
    }
}
struct HumorView: View {
    @State private var humor = "Neutro"
    @State private var observacao = ""
    @State private var apoio = "Como foi o dia?"
    @State private var aviso = ""
    private var valido: Bool { observacao.trimmingCharacters(in: .whitespaces).count >= 8 }
    private var cor: Color { observacao.isEmpty ? .gray : (valido ? .green : .red) }
    var body: some View {
        VStack(spacing: 20) {
            Picker("Humor", selection: $humor) { Text("Feliz").tag("Feliz"); Text("Triste").tag("Triste"); Text("Neutro").tag("Neutro"); Text("Animado").tag("Animado") }.pickerStyle(.segmented)
                .onChange(of: humor) { _, novo in
                    if novo == "Triste" { apoio = "Quer conversar sobre isso?" }
                    else if novo == "Feliz" { apoio = "Que bom! Conte mais..." }
                    else if novo == "Animado" { apoio = "O que te animou?" }
                    else { apoio = "Como foi o dia?" }
                }
            TextField(apoio, text: $observacao, axis: .vertical).textFieldStyle(.roundedBorder).overlay(RoundedRectangle(cornerRadius: 8).stroke(cor, lineWidth: 2))
                .onChange(of: observacao) { _, novo in let n = novo.trimmingCharacters(in: .whitespaces).count; aviso = novo.isEmpty || n >= 8 ? "" : "Escreva pelo menos 8 caracteres." }
            if !aviso.isEmpty { Text(aviso).foregroundStyle(.red).font(.caption) }
            Button("Guardar") { aviso = "Humor guardado: \(humor)." }.buttonStyle(.borderedProminent).disabled(!valido)
            if aviso.hasPrefix("Humor guardado") { Text(aviso).foregroundStyle(.green) }
            Spacer()
        }.padding().navigationTitle("Humor")
    }
}
struct PecaCorView: View {
    @State private var cor = Color.blue
    var body: some View { RoundedRectangle(cornerRadius: 12).fill(cor).frame(width: 85, height: 85).onTapGesture { withAnimation { cor = Color(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1)) } } }
}
struct PecaGiroView: View {
    @State private var angulo = Angle.zero
    var body: some View { RoundedRectangle(cornerRadius: 12).fill(.purple).frame(width: 85, height: 85).rotationEffect(angulo).onLongPressGesture { withAnimation { angulo += .degrees(45) } } }
}
struct PecaDuplaView: View {
    @State private var cor = Color.orange
    @State private var escala: CGFloat = 1
    var body: some View { RoundedRectangle(cornerRadius: 12).fill(cor).frame(width: 85, height: 85).scaleEffect(escala).onTapGesture { withAnimation { cor = Color(red: .random(in: 0...1), green: .random(in: 0...1), blue: .random(in: 0...1)) } }.onLongPressGesture { withAnimation { escala = escala == 1 ? 1.3 : 1 } } }
}
struct PecasView: View {
    @State private var aberturas = 0
    var body: some View { HStack(spacing: 22) { PecaCorView(); PecaGiroView(); PecaDuplaView() }.padding().navigationTitle("Peças").onAppear { aberturas += 1 }.safeAreaInset(edge: .bottom) { Text("Aberturas: \(aberturas)").padding() } }
}

// MARK: - CAPÍTULO 7: LISTAS
struct Filme: Identifiable {
    let id = UUID(); var titulo: String; var ano: Int; var genero: String; var nota: Int; var assistido: Bool
    func corDoGenero(_ nome: String) -> Color { switch nome { case "Ação": return .red; case "Comédia": return .orange; case "Drama": return .blue; case "Animação": return .purple; case "Documentário": return .green; default: return .gray } }
}
struct FilmeCell: View {
    let filme: Filme
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack { Text(filme.titulo).font(.headline); Spacer(); Text(String(filme.ano)).foregroundStyle(.secondary) }
            Text(filme.genero).font(.caption.bold()).foregroundStyle(filme.corDoGenero(filme.genero))
            HStack { ForEach(1...5, id: \.self) { n in Image(systemName: n <= filme.nota ? "star.fill" : "star") .foregroundStyle(.yellow) }; Spacer(); Text(filme.assistido ? "Assistido" : "Não assistido").font(.caption) }
        }
    }
}
struct NovoFilmeView: View {
    let anoLimite: Int; let aoSalvar: (Filme) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var titulo = ""; @State private var ano = "2024"; @State private var genero = "Ação"; @State private var nota = 3
    private var anoNumero: Int? { Int(ano) }
    private var podeSalvar: Bool { !titulo.trimmingCharacters(in: .whitespaces).isEmpty && (anoNumero ?? 0) >= 1900 && (anoNumero ?? (anoLimite + 1)) <= anoLimite }
    var body: some View {
        NavigationStack { Form {
            TextField("Título", text: $titulo); TextField("Ano", text: $ano).keyboardType(.numberPad)
            Picker("Gênero", selection: $genero) { Text("Ação").tag("Ação"); Text("Comédia").tag("Comédia"); Text("Drama").tag("Drama"); Text("Animação").tag("Animação"); Text("Documentário").tag("Documentário") }
            Stepper("Nota: \(nota)", value: $nota, in: 1...5)
        }.navigationTitle("Novo filme").toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) { Button("Salvar") { aoSalvar(Filme(titulo: titulo.trimmingCharacters(in: .whitespaces), ano: anoNumero!, genero: genero, nota: nota, assistido: false)); dismiss() }.disabled(!podeSalvar) }
        } }
    }
}
struct FiltrosFilmeView: View {
    @Binding var situacao: String; @Binding var genero: String; @Binding var notaMinima: Int; @Binding var ordem: String
    @Environment(\.dismiss) private var dismiss
    var body: some View { NavigationStack { Form {
        Picker("Situação", selection: $situacao) { Text("Todos").tag("Todos"); Text("Assistidos").tag("Assistidos"); Text("Não assistidos").tag("Não assistidos") }
        Picker("Gênero", selection: $genero) { Text("Todos").tag("Todos"); Text("Ação").tag("Ação"); Text("Comédia").tag("Comédia"); Text("Drama").tag("Drama"); Text("Animação").tag("Animação"); Text("Documentário").tag("Documentário") }
        Stepper("Nota mínima: \(notaMinima)", value: $notaMinima, in: 1...5)
        Picker("Ordem", selection: $ordem) { Text("Título").tag("Título"); Text("Ano").tag("Ano"); Text("Avaliação").tag("Avaliação") }
    }.navigationTitle("Filtros").toolbar { ToolbarItem(placement: .confirmationAction) { Button("Fechar") { dismiss() } } } } }
}
struct ListaFilmesView: View {
    @State private var filmes: [Filme] = [Filme(titulo:"Interestelar",ano:2014,genero:"Drama",nota:5,assistido:true),Filme(titulo:"Toy Story",ano:1995,genero:"Animação",nota:5,assistido:true),Filme(titulo:"Mad Max",ano:2015,genero:"Ação",nota:4,assistido:false),Filme(titulo:"As Branquelas",ano:2004,genero:"Comédia",nota:4,assistido:false),Filme(titulo:"O Dilema das Redes",ano:2020,genero:"Documentário",nota:4,assistido:true)]
    @State private var mostrarNovo = false; @State private var mostrarFiltros = false
    @State private var situacao = "Todos"; @State private var genero = "Todos"; @State private var notaMinima = 1; @State private var ordem = "Título"
    private var visiveis: [Filme] { var r = filmes.filter { (situacao == "Todos" || (situacao == "Assistidos" ? $0.assistido : !$0.assistido)) && (genero == "Todos" || $0.genero == genero) && $0.nota >= notaMinima }; if ordem == "Ano" { r.sort { $0.ano < $1.ano } } else if ordem == "Avaliação" { r.sort { $0.nota > $1.nota } } else { r.sort { $0.titulo.localizedCaseInsensitiveCompare($1.titulo) == .orderedAscending } }; return r }
    private var assistidos: Int { filmes.filter(\.assistido).count }
    private var media: Double { filmes.isEmpty ? 0 : Double(filmes.reduce(0) { $0 + $1.nota }) / Double(filmes.count) }
    private func alternar(_ filme: Filme) { if let i = filmes.firstIndex(where: { $0.id == filme.id }) { filmes[i].assistido.toggle() } }
    private func apagar(_ filme: Filme) { filmes.removeAll { $0.id == filme.id } }
    var body: some View {
        NavigationStack { List {
            Section("Resumo") {
                Text("Total: \(filmes.count) • Assistidos: \(assistidos)")
                Text("Progresso: \(filmes.isEmpty ? 0 : assistidos * 100 / filmes.count)% • Média: \(media, specifier: "%.1f")")
                ForEach(["Ação","Comédia","Drama","Animação","Documentário"], id: \.self) { g in Text("\(g): \(filmes.filter { $0.genero == g }.count)").foregroundStyle(Filme(titulo:"",ano:0,genero:g,nota:1,assistido:false).corDoGenero(g)) }
            }
            Section("Filmes") { ForEach(visiveis) { filme in HStack { Button { alternar(filme) } label: { Image(systemName: filme.assistido ? "checkmark.circle.fill" : "circle") }; FilmeCell(filme: filme); Button(role: .destructive) { apagar(filme) } label: { Image(systemName: "trash") } }.buttonStyle(.plain) }.onDelete { offsets in let ids = offsets.map { visiveis[$0].id }; ids.forEach { id in filmes.removeAll { $0.id == id } } } }
        }.navigationTitle("Filmes").toolbar {
            ToolbarItem(placement: .topBarLeading) { Button { mostrarFiltros = true } label: { Image(systemName: "line.3.horizontal.decrease.circle") } }
            ToolbarItem(placement: .topBarTrailing) { Button { mostrarNovo = true } label: { Image(systemName: "plus") } }
        }.sheet(isPresented: $mostrarNovo) { NovoFilmeView(anoLimite: Calendar.current.component(.year, from: Date())) { filmes.append($0) } }
        .sheet(isPresented: $mostrarFiltros) { FiltrosFilmeView(situacao: $situacao, genero: $genero, notaMinima: $notaMinima, ordem: $ordem) }
        }
    }
}
struct AlunoChamada: Identifiable { let id = UUID(); var nome: String; var presente: Bool }
struct ChamadaView: View {
    @State private var alunos = [AlunoChamada(nome:"Ana",presente:true),AlunoChamada(nome:"Bruno",presente:true),AlunoChamada(nome:"Caio",presente:false),AlunoChamada(nome:"Duda",presente:true)]
    @State private var novoAluno = ""; @State private var filtro = "Todos"
    private var visiveis: [AlunoChamada] { filtro == "Presentes" ? alunos.filter(\.presente) : (filtro == "Ausentes" ? alunos.filter { !$0.presente } : alunos) }
    private var totalPresentes: Int { alunos.filter(\.presente).count }
    private func alternar(_ aluno: AlunoChamada) { if let i = alunos.firstIndex(where: { $0.id == aluno.id }) { alunos[i].presente.toggle() } }
    var body: some View { VStack {
        Picker("Filtro", selection: $filtro) { Text("Todos").tag("Todos"); Text("Presentes").tag("Presentes"); Text("Ausentes").tag("Ausentes") }.pickerStyle(.segmented).padding()
        HStack { TextField("Novo aluno", text: $novoAluno).textFieldStyle(.roundedBorder); Button { let n = novoAluno.trimmingCharacters(in: .whitespaces); if !n.isEmpty { alunos.append(AlunoChamada(nome:n,presente:false)); novoAluno = "" } } label: { Image(systemName:"plus.circle.fill") }.disabled(novoAluno.trimmingCharacters(in: .whitespaces).isEmpty) }.padding(.horizontal)
        List { ForEach(visiveis) { aluno in Button { alternar(aluno) } label: { HStack { Image(systemName: aluno.presente ? "checkmark.circle.fill" : "circle").foregroundStyle(aluno.presente ? .green : .secondary); Text(aluno.nome); Spacer() } }.foregroundStyle(.primary) }.onDelete { offsets in let ids = offsets.map { visiveis[$0].id }; alunos.removeAll { ids.contains($0.id) } } }
        Text("\(totalPresentes) de \(alunos.count) presentes").font(.headline).padding()
    }.navigationTitle("Chamada") }
}
struct JogadorRanking: Identifiable { let id = UUID(); var nome: String; var pontos: Int }
struct RankingView: View {
    @State private var jogadores = [JogadorRanking(nome:"Ana",pontos:75),JogadorRanking(nome:"Bruno",pontos:42),JogadorRanking(nome:"Caio",pontos:90),JogadorRanking(nome:"Duda",pontos:58)]
    @State private var soAcimaDe50 = false
    private var visiveis: [JogadorRanking] { soAcimaDe50 ? jogadores.filter { $0.pontos > 50 } : jogadores }
    private var total: Int { jogadores.reduce(0) { $0 + $1.pontos } }
    private var nomes: String { jogadores.map(\.nome).joined(separator: ", ") }
    var body: some View { List {
        Section("Resumo") { Text("Total de pontos: \(total)"); Text("Turma: \(nomes)") }
        Toggle("Só quem passou de 50", isOn: $soAcimaDe50)
        ForEach(visiveis) { jogador in HStack { VStack(alignment:.leading) { Text(jogador.nome).font(.headline); Text("\(jogador.pontos) pontos").foregroundStyle(.secondary) }; Spacer(); Button("+10") { if let i = jogadores.firstIndex(where: { $0.id == jogador.id }) { jogadores[i].pontos += 10 } }.buttonStyle(.borderedProminent) } }
    }.navigationTitle("Ranking") }
}

// MARK: - CAPÍTULO 8: NAVEGAÇÃO E SHEETS
struct Colega: Identifiable { let id = UUID(); var nome: String; var interesse: String }
struct ColegaDetalheView: View { let colega: Colega; var body: some View { Form { Text("Interesse: \(colega.interesse)") }.navigationTitle(colega.nome) } }
struct TurmaView: View {
    let nomeUsuario: String
    private let colegas = [Colega(nome:"Ana",interesse:"Basquete"),Colega(nome:"Bruno",interesse:"Música"),Colega(nome:"Caio",interesse:"Programação"),Colega(nome:"Duda",interesse:"Leitura")]
    var body: some View { NavigationStack { List { Text("Olá, \(nomeUsuario)"); ForEach(colegas) { colega in NavigationLink { ColegaDetalheView(colega: colega) } label: { HStack { Text(colega.nome); Spacer(); Image(systemName:"chevron.right").font(.caption).foregroundStyle(.secondary) } } } }.navigationTitle("Turma") } }
}
struct RecadoView: View {
    @State private var mostrarForm = false
    @State private var recadoPublicado = ""
    var body: some View { NavigationStack { VStack(spacing:20) { Text(recadoPublicado.isEmpty ? "Nenhum recado" : recadoPublicado).font(.title3).multilineTextAlignment(.center).padding(); Button("Novo recado", systemImage:"plus") { mostrarForm = true }.buttonStyle(.borderedProminent) }.padding().navigationTitle("Recado") }.sheet(isPresented:$mostrarForm) { RecadoFormView(recadoPublicado:$recadoPublicado) } }
}
struct RecadoFormView: View {
    @Binding var recadoPublicado: String
    @Environment(\.dismiss) private var dismiss
    @State private var rascunho = ""
    var body: some View { NavigationStack { Form { TextField("Recado", text:$rascunho).textFieldStyle(.roundedBorder) }.navigationTitle("Novo recado").toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button("Publicar") { recadoPublicado = rascunho.trimmingCharacters(in:.whitespaces); dismiss() }.disabled(rascunho.trimmingCharacters(in:.whitespaces).isEmpty) } } } }
}
struct AjustesView: View {
    @Binding var nomeUsuario: String; @Binding var modoEscuro: Bool
    @State private var confirmarSaida = false; @State private var saiu = false
    var body: some View { NavigationStack { Form {
        if saiu { Text("Sessão encerrada.").foregroundStyle(.secondary) } else {
            TextField("Nome", text:$nomeUsuario)
            Toggle("Modo escuro", isOn:$modoEscuro)
            Button("Sair", role:.destructive) { confirmarSaida = true }
        }
    }.navigationTitle("Ajustes").alert("Deseja sair do mural?", isPresented:$confirmarSaida) { Button("Cancelar",role:.cancel) {}; Button("Sair",role:.destructive) { saiu = true } } } }
}
struct MuralView: View {
    @State private var nomeUsuario = "Aluno"; @State private var modoEscuro = false
    var body: some View { TabView {
        TurmaView(nomeUsuario:nomeUsuario).tabItem { Label("Turma",systemImage:"person.2") }
        RecadoView().tabItem { Label("Recado",systemImage:"text.bubble") }
        AjustesView(nomeUsuario:$nomeUsuario,modoEscuro:$modoEscuro).tabItem { Label("Ajustes",systemImage:"gearshape") }
    }.preferredColorScheme(modoEscuro ? .dark : .light) }
}
struct LocalEscola: Identifiable { let id = UUID(); var nome: String; var horario: String; var piso: String }
struct LocalDetalheView: View { let local: LocalEscola; var body: some View { Form { Text("Horário: \(local.horario)"); Text("Piso: \(local.piso)") }.navigationTitle(local.nome) } }
struct GuiaEscolaView: View {
    private let locais = [LocalEscola(nome:"Biblioteca",horario:"07h às 18h",piso:"1º piso"),LocalEscola(nome:"Laboratório",horario:"08h às 17h",piso:"2º piso"),LocalEscola(nome:"Quadra",horario:"07h às 20h",piso:"Área externa"),LocalEscola(nome:"Cantina",horario:"07h às 19h",piso:"Térreo")]
    var body: some View { NavigationStack { List(locais) { local in NavigationLink { LocalDetalheView(local:local) } label: { VStack(alignment:.leading) { Text(local.nome); Text(local.horario).font(.caption).foregroundStyle(.secondary) } } }.navigationTitle("Guia") } }
}
struct Lanche: Identifiable { let id = UUID(); var nome: String; var preco: Double }
struct LancheDetalheView: View { let lanche: Lanche; var body: some View { VStack(spacing:16) { Text(lanche.preco,format:.currency(code:"BRL")).font(.title2) }.padding().navigationTitle(lanche.nome) } }
struct PedidoSheetView: View {
    @Binding var pedido: String
    @Environment(\.dismiss) private var dismiss
    @State private var lancheEscolhido = ""
    @State private var observacao = ""
    let lanches: [Lanche]
    var body: some View { NavigationStack { Form {
        Picker("Lanche",selection:$lancheEscolhido) { Text("Selecione").tag(""); ForEach(lanches) { item in Text(item.nome).tag(item.nome) } }
        TextField("Observação",text:$observacao)
    }.navigationTitle("Novo pedido").toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button("Confirmar") { let extra = observacao.trimmingCharacters(in:.whitespaces); pedido = extra.isEmpty ? lancheEscolhido : "\(lancheEscolhido) — \(extra)"; dismiss() }.disabled(lancheEscolhido.isEmpty) } } } }
}
struct CardapioCantinaView: View {
    let lanches: [Lanche]
    var body: some View { NavigationStack { List(lanches) { lanche in NavigationLink { LancheDetalheView(lanche:lanche) } label: { HStack { Text(lanche.nome); Spacer(); Text(lanche.preco,format:.currency(code:"BRL")) } } }.navigationTitle("Cardápio") } }
}
struct PedidoCantinaView: View {
    @Binding var pedido: String
    let lanches: [Lanche]
    @State private var mostrarPedido = false
    var body: some View { NavigationStack { VStack(spacing:20) { Text(pedido.isEmpty ? "Nenhum pedido" : pedido).font(.title3).multilineTextAlignment(.center); Button("Novo pedido") { mostrarPedido = true }.buttonStyle(.borderedProminent) }.padding().navigationTitle("Pedido") }.sheet(isPresented:$mostrarPedido) { PedidoSheetView(pedido:$pedido,lanches:lanches) } }
}
struct CantinaView: View {
    @State private var pedido = ""
    private let lanches = [Lanche(nome:"Pão de queijo",preco:6),Lanche(nome:"Sanduíche natural",preco:12),Lanche(nome:"Suco natural",preco:7),Lanche(nome:"Bolo",preco:8)]
    var body: some View { TabView {
        CardapioCantinaView(lanches:lanches).tabItem { Label("Cardápio",systemImage:"fork.knife") }
        PedidoCantinaView(pedido:$pedido,lanches:lanches).tabItem { Label("Pedido",systemImage:"bag") }
    } }
}

// MARK: - REVISÃO: VIEWMODELS E MÚLTIPLAS TELAS
struct Livro: Identifiable { let id = UUID(); var titulo: String; var autor: String; var paginas: Int; var lido: Bool }
final class EstanteViewModel: ObservableObject {
    @Published var livros = [Livro(titulo:"O Pequeno Príncipe",autor:"Antoine de Saint-Exupéry",paginas:96,lido:true),Livro(titulo:"Dom Casmurro",autor:"Machado de Assis",paginas:256,lido:false),Livro(titulo:"A Revolução dos Bichos",autor:"George Orwell",paginas:152,lido:false),Livro(titulo:"Capitães da Areia",autor:"Jorge Amado",paginas:280,lido:true)]
    var total: Int { livros.count }; var lidos: Int { livros.filter(\.lido).count }; var paginas: Int { livros.filter(\.lido).reduce(0) { $0 + $1.paginas } }
    func adicionar(titulo:String,autor:String,paginas:Int) { livros.append(Livro(titulo:titulo,autor:autor,paginas:paginas,lido:false)) }
    func apagar(id:UUID) { livros.removeAll { $0.id == id } }
    func livro(id:UUID) -> Livro? { livros.first { $0.id == id } }
    func definirLido(id:UUID,lido:Bool) { if let i = livros.firstIndex(where:{$0.id == id}) { livros[i].lido = lido } }
}
struct EstanteView: View {
    @StateObject private var estante = EstanteViewModel(); @State private var mostrarNovo = false
    var body: some View { NavigationStack { List {
        Section("Resumo") { Text("Livros: \(estante.total)"); Text("Lidos: \(estante.lidos)"); Text("Páginas na estante: \(estante.paginas)") }
        Section("Estante") { ForEach(estante.livros) { livro in NavigationLink { LivroDetalheView(estante:estante,livroId:livro.id) } label: { VStack(alignment:.leading) { Text(livro.titulo); Text(livro.autor).font(.caption).foregroundStyle(.secondary) } } }.onDelete { offsets in let ids = offsets.map { estante.livros[$0].id }; ids.forEach { estante.apagar(id:$0) } } }
    }.navigationTitle("Estante").toolbar { Button { mostrarNovo = true } label: { Image(systemName:"plus") } }.sheet(isPresented:$mostrarNovo) { NovoLivroView(estante:estante) } } }
}
struct LivroDetalheView: View {
    @ObservedObject var estante: EstanteViewModel; let livroId: UUID
    private var livro: Livro? { estante.livro(id:livroId) }
    var body: some View { Form { if let livro { LabeledContent("Autor",value:livro.autor); LabeledContent("Páginas",value:String(livro.paginas)); Toggle("Lido",isOn:Binding(get:{estante.livro(id:livroId)?.lido ?? false},set:{estante.definirLido(id:livroId,lido:$0)})) } }.navigationTitle(livro?.titulo ?? "Livro") }
}
struct NovoLivroView: View {
    @ObservedObject var estante: EstanteViewModel; @Environment(\.dismiss) private var dismiss
    @State private var titulo = ""; @State private var autor = ""; @State private var paginas = 100
    private var podeSalvar: Bool { !titulo.trimmingCharacters(in:.whitespaces).isEmpty && !autor.trimmingCharacters(in:.whitespaces).isEmpty }
    var body: some View { NavigationStack { Form { TextField("Título",text:$titulo); TextField("Autor",text:$autor); Stepper("Páginas: \(paginas)",value:$paginas,in:1...2000) }.navigationTitle("Novo livro").toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button("Salvar") { estante.adicionar(titulo:titulo.trimmingCharacters(in:.whitespaces),autor:autor.trimmingCharacters(in:.whitespaces),paginas:paginas); dismiss() }.disabled(!podeSalvar) } } } }
}
struct EquipeLab: Identifiable { let id = UUID(); var nome:String; var tema:String; var integrantes:Int }
final class LaboratorioViewModel: ObservableObject {
    @Published var equipes = [EquipeLab(nome:"Equipe Alfa",tema:"Robótica",integrantes:4),EquipeLab(nome:"Equipe Beta",tema:"Sustentabilidade",integrantes:5),EquipeLab(nome:"Equipe Gama",tema:"Jogos",integrantes:3),EquipeLab(nome:"Equipe Delta",tema:"Inteligência artificial",integrantes:6)]
    @Published var aviso = ""
    var totalIntegrantes: Int { equipes.reduce(0) { $0 + $1.integrantes } }
    func apagar(id:UUID) { equipes.removeAll { $0.id == id } }
    func definirIntegrantes(id:UUID,valor:Int) { if let i = equipes.firstIndex(where:{$0.id == id}) { equipes[i].integrantes = valor } }
    func equipe(id:UUID) -> EquipeLab? { equipes.first { $0.id == id } }
    func publicarAviso(_ texto:String) { aviso = texto }
}
struct LaboratorioView: View {
    @StateObject private var laboratorio = LaboratorioViewModel()
    var body: some View { TabView { EquipesLabView(laboratorio:laboratorio).tabItem { Label("Equipes",systemImage:"person.3") }; AvisoLabView(laboratorio:laboratorio).tabItem { Label("Aviso",systemImage:"megaphone") } } }
}
struct EquipesLabView: View {
    @ObservedObject var laboratorio: LaboratorioViewModel
    var body: some View { NavigationStack { List { Text("Integrantes: \(laboratorio.totalIntegrantes)"); ForEach(laboratorio.equipes) { equipe in NavigationLink { EquipeLabDetalheView(laboratorio:laboratorio,equipeId:equipe.id) } label: { VStack(alignment:.leading) { Text(equipe.nome); Text(equipe.tema).font(.caption).foregroundStyle(.secondary) } } }.onDelete { offsets in let ids = offsets.map { laboratorio.equipes[$0].id }; ids.forEach { laboratorio.apagar(id:$0) } } }.navigationTitle("Equipes") } }
}
struct EquipeLabDetalheView: View {
    @ObservedObject var laboratorio: LaboratorioViewModel; let equipeId:UUID
    private var equipe: EquipeLab? { laboratorio.equipe(id:equipeId) }
    var body: some View { Form { if let equipe { LabeledContent("Tema",value:equipe.tema); Stepper("Integrantes: \(equipe.integrantes)",value:Binding(get:{laboratorio.equipe(id:equipeId)?.integrantes ?? 1},set:{laboratorio.definirIntegrantes(id:equipeId,valor:$0)}),in:1...12) } }.navigationTitle(equipe?.nome ?? "Equipe") }
}
struct AvisoLabView: View {
    @ObservedObject var laboratorio: LaboratorioViewModel; @State private var mostrarForm = false
    var body: some View { NavigationStack { VStack(spacing:20) { Text(laboratorio.aviso.isEmpty ? "Nenhum aviso" : laboratorio.aviso).font(.title3).multilineTextAlignment(.center); Button("Novo aviso") { mostrarForm = true }.buttonStyle(.borderedProminent) }.padding().navigationTitle("Aviso") }.sheet(isPresented:$mostrarForm) { AvisoLabFormView(laboratorio:laboratorio) } }
}
struct AvisoLabFormView: View {
    @ObservedObject var laboratorio:LaboratorioViewModel; @Environment(\.dismiss) private var dismiss; @State private var rascunho = ""
    var body: some View { NavigationStack { VStack { TextField("Aviso",text:$rascunho).textFieldStyle(.roundedBorder); Button("Publicar") { laboratorio.publicarAviso(rascunho.trimmingCharacters(in:.whitespaces)); dismiss() }.buttonStyle(.borderedProminent).disabled(rascunho.trimmingCharacters(in:.whitespaces).isEmpty); Spacer() }.padding().navigationTitle("Novo aviso") } }
}
struct ItemProva: Identifiable { let id = UUID(); var materia:String; var sala:String; var dia:Date; var revisada:Bool }
final class AgendaProvasViewModel: ObservableObject {
    @Published var provas:[ItemProva] = [ItemProva(materia:"Matemática",sala:"Sala 1",dia:Calendar.current.date(byAdding:.day,value:2,to:Date())!,revisada:false),ItemProva(materia:"História",sala:"Sala 2",dia:Calendar.current.date(byAdding:.day,value:5,to:Date())!,revisada:true),ItemProva(materia:"Programação",sala:"Laboratório",dia:Calendar.current.date(byAdding:.day,value:8,to:Date())!,revisada:false),ItemProva(materia:"Inglês",sala:"Sala 3",dia:Calendar.current.date(byAdding:.day,value:12,to:Date())!,revisada:false)]
    @Published var soPendentes = false
    var visiveis:[ItemProva] { (soPendentes ? provas.filter{ !$0.revisada } : provas).sorted{$0.dia < $1.dia} }
    var pendentes:Int { provas.filter{ !$0.revisada }.count }
    func adicionar(materia:String,sala:String,dia:Date) { provas.append(ItemProva(materia:materia,sala:sala,dia:dia,revisada:false)) }
    func apagar(id:UUID) { provas.removeAll{$0.id == id} }
    func prova(id:UUID)->ItemProva? { provas.first{$0.id == id} }
    func definirRevisada(id:UUID,revisada:Bool) { if let i = provas.firstIndex(where:{$0.id == id}) { provas[i].revisada = revisada } }
}
struct AgendaProvasView: View {
    @StateObject private var agenda = AgendaProvasViewModel(); @State private var mostrarNova = false
    var body: some View { NavigationStack { List {
        Section("Resumo") { Text("Total: \(agenda.provas.count)"); Text("Pendentes: \(agenda.pendentes)"); Toggle("Só as pendentes",isOn:$agenda.soPendentes) }
        Section("Provas") { ForEach(agenda.visiveis) { prova in NavigationLink { ProvaDetalheView(agenda:agenda,provaId:prova.id) } label: { VStack(alignment:.leading) { Text(prova.materia).font(.headline); Text("\(prova.sala) • \(prova.revisada ? "Revisada" : "Pendente")").font(.caption).foregroundStyle(.secondary) } } }.onDelete { offsets in let ids = offsets.map { agenda.visiveis[$0].id }; ids.forEach { agenda.apagar(id:$0) } } }
    }.navigationTitle("Provas").toolbar { Button { mostrarNova = true } label: { Image(systemName:"plus") } }.sheet(isPresented:$mostrarNova) { NovaProvaView(agenda:agenda) } } }
}
struct ProvaDetalheView: View {
    @ObservedObject var agenda:AgendaProvasViewModel; let provaId:UUID; @Environment(\.dismiss) private var dismiss; @State private var confirmarApagar = false
    private var prova:ItemProva? { agenda.prova(id:provaId) }
    var body: some View { Form { if let prova { LabeledContent("Sala",value:prova.sala); LabeledContent("Dia") { Text(prova.dia,format:.dateTime.day().month(.wide).year()) }; Toggle("Revisada",isOn:Binding(get:{agenda.prova(id:provaId)?.revisada ?? false},set:{agenda.definirRevisada(id:provaId,revisada:$0)})); Button("Apagar",role:.destructive) { confirmarApagar = true } } }.navigationTitle(prova?.materia ?? "Prova").alert("Apagar esta prova?",isPresented:$confirmarApagar) { Button("Apagar",role:.destructive) { agenda.apagar(id:provaId); dismiss() }; Button("Cancelar",role:.cancel) {} } }
}
struct NovaProvaView: View {
    @ObservedObject var agenda:AgendaProvasViewModel; @Environment(\.dismiss) private var dismiss; @State private var materia = ""; @State private var sala = ""; @State private var dia = Date()
    private var podeSalvar:Bool { !materia.trimmingCharacters(in:.whitespaces).isEmpty && !sala.trimmingCharacters(in:.whitespaces).isEmpty }
    var body: some View { NavigationStack { Form { TextField("Matéria",text:$materia); TextField("Sala",text:$sala); DatePicker("Dia",selection:$dia,displayedComponents:.date) }.navigationTitle("Nova prova").toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancelar") { dismiss() } }; ToolbarItem(placement:.confirmationAction) { Button("Salvar") { agenda.adicionar(materia:materia.trimmingCharacters(in:.whitespaces),sala:sala.trimmingCharacters(in:.whitespaces),dia:dia); dismiss() }.disabled(!podeSalvar) } } } }
}
